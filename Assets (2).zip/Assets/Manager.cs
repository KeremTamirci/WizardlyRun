using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Manager : MonoBehaviour
{
    public GameObject startPanel;
    public GameObject inGamePanel;
    public GameObject deathPanel;
    public GameObject endPanel;
    public Movement mv;
    public autoShoott aus;
    public TouchDragControls1 tdc1;
    public bool hasStarted;
    // Start is called before the first frame update
    void Start()
    {
        deathPanel.SetActive(false);
        hasStarted = false;
        inGamePanel.SetActive(false);
        startPanel.SetActive(true);
        endPanel.SetActive(false);
        DisablePlayer();
    }
    public void DisablePlayer()
    {
        mv.enabled = false;
        aus.enabled = false;
        tdc1.enabled = false;
    }
    public void EnablePlayer()
    {
        mv.enabled = true;
        aus.enabled = true;
        tdc1.enabled = true;
    }

    // Update is called once per frame
    void Update()
    {
    }
    public void StartFunction()
    {
        Debug.Log("Bastı");
        hasStarted = true;
        tdc1.started = true;
        inGamePanel.SetActive(true);
        startPanel.SetActive(false);
        EnablePlayer();
    }
    public void DeathFunction()
    {
        inGamePanel.SetActive(false);
        startPanel.SetActive(false);
        deathPanel.SetActive(true);

    }
    public void ReloadFunc()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
    public void NextLevel()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex+1);
    }
    public void LevelEnded()
    {
        deathPanel.SetActive(false);
        inGamePanel.SetActive(false);
        startPanel.SetActive(false);
        endPanel.SetActive(true);
        DisablePlayer();
    }
}