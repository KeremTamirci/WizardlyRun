using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class die : MonoBehaviour
{
    public Animator anim;
    public bool isDead;
    public Manager mng;
    public Rigidbody rb;
    // Start is called before the first frame update
    void Start()
    {
        anim = GetComponent<Animator>();
        isDead = false;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnCollisionEnter(Collision collision)
    {
        if(collision.collider.tag is "enemy" ||collision.collider.tag is "obstacle")
        {
            isDead = true;
            Debug.Log("öldüm");
            anim.SetBool("dead", true);
            FindObjectOfType<Manager>().DisablePlayer();
            rb.velocity = new Vector3(0, 0, 0);
            FindObjectOfType<Manager>().DeathFunction();
        }
    }
}