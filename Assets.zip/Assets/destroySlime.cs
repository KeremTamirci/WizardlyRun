using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class destroySlime : MonoBehaviour
{

    public int lives = 5;

    void OnCollisionEnter(Collision collider)
    {
        if (collider.collider.tag is "sphere"){
            lives--;
            if (lives <= 0){
                Destroy(gameObject);
            }
        }
    }
}
