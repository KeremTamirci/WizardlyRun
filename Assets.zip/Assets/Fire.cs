using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Fire : MonoBehaviour
{
    
    [SerializeField]
    private GameObject _spherePrefab;
    public autoShoot aS;

    // Start is called before the first frame update
    void Start()
    {
        
    }
    public void Shoot()
    {
        
            Instantiate(_spherePrefab, transform.position + new Vector3(-0.05f, 1, 0.6f), Quaternion.identity);
        
    }
    // Update is called once per frame
    void Update()
    {



    }
}