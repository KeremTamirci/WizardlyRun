﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TouchDragControls : MonoBehaviour
{

    private Touch touch;
    public float speedMod;
    public Rigidbody wizard;
    // Start is called before the first frame update
    void Start()
    {
        speedMod = 0.2f;
    }

    // Update is called once per frame
    void Update()
    {

        if (transform.position.x > 3) {
            transform.position = new Vector3(
            3,
            transform.position.y,
            transform.position.z
        );
        }

        if (transform.position.x < -3) {
            transform.position = new Vector3(
                -3,
                transform.position.y,
                transform.position.z
            );
        }

        if(Input.touchCount > 0)
        {
            touch = Input.GetTouch(0);
        
            if(touch.phase == TouchPhase.Moved)
            {
                wizard.velocity = new Vector3(
                    transform.position.x + touch.deltaPosition.x * speedMod,
                    wizard.velocity.y,
                    wizard.velocity.z
                );

            }
        }
        
    }
}
